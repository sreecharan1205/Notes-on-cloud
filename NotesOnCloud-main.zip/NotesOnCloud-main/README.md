In the project directory, you can run:

# npm start
Runs the app in the development mode.
Open http://localhost:3000 to view it in your browser.

##  Check out the live demo of my project on predicting heart disease using machine learning at https://notesoncloud1.netlify.app/
